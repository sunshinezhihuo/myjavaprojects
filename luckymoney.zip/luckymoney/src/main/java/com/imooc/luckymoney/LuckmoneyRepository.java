package com.imooc.luckymoney;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by 廖师兄
 * 2019-03-11 21:38
 */
public interface LuckmoneyRepository extends JpaRepository<Luckymoney, Integer> {
}
